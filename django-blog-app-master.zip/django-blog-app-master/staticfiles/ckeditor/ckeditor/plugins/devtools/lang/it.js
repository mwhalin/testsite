﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","it",{title:"Informazioni elemento",dialogName:"Nome finestra di dialogo",tabName:"Nome Tab",elementId:"ID Elemento",elementType:"Tipo elemento"});